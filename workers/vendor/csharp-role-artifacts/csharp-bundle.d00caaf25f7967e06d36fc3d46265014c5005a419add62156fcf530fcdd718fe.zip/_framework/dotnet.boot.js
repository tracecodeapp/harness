export const config = /*json-start*/{
  "mainAssemblyName": "TraceCode.CSharpJudgeRunner.dll",
  "resources": {
    "hash": "sha256-iGZDkcE8PnIYOgjdjAIVgwPNWMZTENzL5E9zaMy+A7c=",
    "jsModuleNative": [
      {
        "name": "dotnet.native.js"
      }
    ],
    "jsModuleRuntime": [
      {
        "name": "dotnet.runtime.js"
      }
    ],
    "wasmNative": [
      {
        "name": "dotnet.native.wasm",
        "hash": "sha256-tYBIdAo9EyjakfG3v/deK81mdHrIcUhBKnOMXvk3Zqs="
      }
    ],
    "coreAssembly": [
      {
        "virtualPath": "System.Private.CoreLib.wasm",
        "name": "System.Private.CoreLib.wasm",
        "hash": "sha256-A79fPYHAiXCrQ5AamrFz0emHwwSBZEGHG0syyeWF8KI="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.JavaScript.wasm",
        "name": "System.Runtime.InteropServices.JavaScript.wasm",
        "hash": "sha256-Dtnp3dUE62o3VF6nA/nQWHWK9m8MFWcvYlaHM9s1pyE="
      }
    ],
    "assembly": [
      {
        "virtualPath": "Microsoft.CSharp.wasm",
        "name": "Microsoft.CSharp.wasm",
        "hash": "sha256-IVKrDMwHpZJfsR2bpqqrw1p4ZAGSDdpS0DXfH5nTtok="
      },
      {
        "virtualPath": "Microsoft.Win32.Primitives.wasm",
        "name": "Microsoft.Win32.Primitives.wasm",
        "hash": "sha256-ynMBS+OYCxCmQSbz2XM23eZ+GNSoDJoeanA/Zrlw+P0="
      },
      {
        "virtualPath": "mscorlib.wasm",
        "name": "mscorlib.wasm",
        "hash": "sha256-4xZref2dp5XlYnmGoVL/6J1GoU4sKxKtmaLb0ACyX6U="
      },
      {
        "virtualPath": "netstandard.wasm",
        "name": "netstandard.wasm",
        "hash": "sha256-hZj3RhkRq9yIylTFhIoIDDaF2d+reV6jCEHqZEtrGW4="
      },
      {
        "virtualPath": "System.Collections.Concurrent.wasm",
        "name": "System.Collections.Concurrent.wasm",
        "hash": "sha256-8Cvme42xfLo2751OZxo6pr4nB1sMJFi1Kr+Sra9EbjA="
      },
      {
        "virtualPath": "System.Collections.wasm",
        "name": "System.Collections.wasm",
        "hash": "sha256-UpxlC4DsdefY4t1O92qocCuvA4mfDnMRMaj/y0GKZhU="
      },
      {
        "virtualPath": "System.Collections.Immutable.wasm",
        "name": "System.Collections.Immutable.wasm",
        "hash": "sha256-CFX+AmMXkaoRKAC26v4amAN5179ERnuJyy0IKzC6eto="
      },
      {
        "virtualPath": "System.Collections.NonGeneric.wasm",
        "name": "System.Collections.NonGeneric.wasm",
        "hash": "sha256-Zng5P963Sr2E0fbkt1TKlWpBb3AzvqOmC5B4gDJ3nws="
      },
      {
        "virtualPath": "System.Collections.Specialized.wasm",
        "name": "System.Collections.Specialized.wasm",
        "hash": "sha256-q5LGQXYbISLukc2YKaiyo9cBn0DDJw2e5Ejt55M4AyI="
      },
      {
        "virtualPath": "System.ComponentModel.wasm",
        "name": "System.ComponentModel.wasm",
        "hash": "sha256-A3cXygK2O5szILGJVXRvAq3Ru/guTxRmqMOiy1cnmVc="
      },
      {
        "virtualPath": "System.ComponentModel.Primitives.wasm",
        "name": "System.ComponentModel.Primitives.wasm",
        "hash": "sha256-RJwaEBBewVWhR61o+54CZMIPGALyt+D241EgY0vqzFk="
      },
      {
        "virtualPath": "System.ComponentModel.TypeConverter.wasm",
        "name": "System.ComponentModel.TypeConverter.wasm",
        "hash": "sha256-jF4RN6Bl9xw5OBdM31+K1YTOVUhXlYEzDTs+uYuJbh0="
      },
      {
        "virtualPath": "System.Console.wasm",
        "name": "System.Console.wasm",
        "hash": "sha256-UxM1g7rwJ+QcGNLeH2CnypT4VwA5nN/2ZJFf5jT0Hb4="
      },
      {
        "virtualPath": "System.Core.wasm",
        "name": "System.Core.wasm",
        "hash": "sha256-qIPHvKCSNuZC0k/4WFAPxmbcwxIqli5JD3uWcTxxYvU="
      },
      {
        "virtualPath": "System.Diagnostics.Contracts.wasm",
        "name": "System.Diagnostics.Contracts.wasm",
        "hash": "sha256-tYCD/okFebjgfSd9az4U87qI8lMc85TnROFWsL8iYKE="
      },
      {
        "virtualPath": "System.Diagnostics.DiagnosticSource.wasm",
        "name": "System.Diagnostics.DiagnosticSource.wasm",
        "hash": "sha256-xCbxgA5aj6vDkGzdwddrMPfECD/0GVFMe0zVplk+Mb8="
      },
      {
        "virtualPath": "System.Diagnostics.StackTrace.wasm",
        "name": "System.Diagnostics.StackTrace.wasm",
        "hash": "sha256-URyF7Iu1NKx4Dka9Qf65T6ual/+83ciyR2Q801ukSS8="
      },
      {
        "virtualPath": "System.Diagnostics.Tracing.wasm",
        "name": "System.Diagnostics.Tracing.wasm",
        "hash": "sha256-FeiXHVfLH0g2mdRIAP54Irczbkfh48Qaey3OEltP2es="
      },
      {
        "virtualPath": "System.wasm",
        "name": "System.wasm",
        "hash": "sha256-b2pM5AvPGIclJq1gPUoMSVqLS4swK3YXvozvDLoViu0="
      },
      {
        "virtualPath": "System.IO.MemoryMappedFiles.wasm",
        "name": "System.IO.MemoryMappedFiles.wasm",
        "hash": "sha256-i8qCdBUEXc3ymRNVvSNrEEznrZkFeUBCVYyffI83aUw="
      },
      {
        "virtualPath": "System.IO.Pipelines.wasm",
        "name": "System.IO.Pipelines.wasm",
        "hash": "sha256-/vYeY9w0DRblvM0U3315D9T+DLHvPJvmCpCms3sng50="
      },
      {
        "virtualPath": "System.Linq.wasm",
        "name": "System.Linq.wasm",
        "hash": "sha256-vZGbIFA4DvVPLU+Y/7gvFDmuvmXCA8lN5AX5jZTBqIs="
      },
      {
        "virtualPath": "System.Linq.Expressions.wasm",
        "name": "System.Linq.Expressions.wasm",
        "hash": "sha256-sLQoMtToK96Yrw0gIRF9bCltX5L5bH/P7PjfBqkyb+Q="
      },
      {
        "virtualPath": "System.Memory.wasm",
        "name": "System.Memory.wasm",
        "hash": "sha256-bKRvXyzjS55Y0fwp1OtsTY6VgitoUqqBYzobSRM6ci8="
      },
      {
        "virtualPath": "System.Numerics.Vectors.wasm",
        "name": "System.Numerics.Vectors.wasm",
        "hash": "sha256-cmwGT/81JOU+0dylMG6GE6BuR42xyTVrqai8jIn/S5o="
      },
      {
        "virtualPath": "System.ObjectModel.wasm",
        "name": "System.ObjectModel.wasm",
        "hash": "sha256-hZFTCP8tBcyv9UhxRwlqhChDinDsUE2yM+2E1eQWDlE="
      },
      {
        "virtualPath": "System.Private.Uri.wasm",
        "name": "System.Private.Uri.wasm",
        "hash": "sha256-nh+cMMDIbTYdlHiYEawHPCmV1cwr0E9/xyxlF6JLItU="
      },
      {
        "virtualPath": "System.Reflection.Emit.wasm",
        "name": "System.Reflection.Emit.wasm",
        "hash": "sha256-9yw2OTYBlb4g4y7qwEG2+eLEihvWm0vPX4Dv8eAdmX8="
      },
      {
        "virtualPath": "System.Reflection.Emit.ILGeneration.wasm",
        "name": "System.Reflection.Emit.ILGeneration.wasm",
        "hash": "sha256-ZpoHIwpmylmrgMyDmRPjxdM72J5+yLnyLLPO4Qdao7Y="
      },
      {
        "virtualPath": "System.Reflection.Emit.Lightweight.wasm",
        "name": "System.Reflection.Emit.Lightweight.wasm",
        "hash": "sha256-9QibfS10I5J8PpwateUUq+ZClGXyazsL8Vldl2csrd4="
      },
      {
        "virtualPath": "System.Reflection.Metadata.wasm",
        "name": "System.Reflection.Metadata.wasm",
        "hash": "sha256-4bo9Gu3ajxhKT2j9+pzpzHtFupoGjWVmAKVyBHRuS2E="
      },
      {
        "virtualPath": "System.Reflection.Primitives.wasm",
        "name": "System.Reflection.Primitives.wasm",
        "hash": "sha256-su5enJcD88ln3NvTee0IOFhkR4WT9pWa0kmYmyeLnuI="
      },
      {
        "virtualPath": "System.Resources.Writer.wasm",
        "name": "System.Resources.Writer.wasm",
        "hash": "sha256-qHJiC/lgPkqJqq4xhVcwgXHixCe5Xm5JQZV7uaeBK+g="
      },
      {
        "virtualPath": "System.Runtime.wasm",
        "name": "System.Runtime.wasm",
        "hash": "sha256-r0YgJoVMv7EAtM3O27t/UvEQeUhGaUhRBU3CAtrEIL0="
      },
      {
        "virtualPath": "System.Runtime.Extensions.wasm",
        "name": "System.Runtime.Extensions.wasm",
        "hash": "sha256-vbKUcf3xTDH7pNsAYFr2jzPXC9Bvwk1BQ4kwVNe4Gbc="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.wasm",
        "name": "System.Runtime.InteropServices.wasm",
        "hash": "sha256-Rf/9xGicv9+Xt3DHeFMdnRuOaXfjmwZbyh7yj5ELYu0="
      },
      {
        "virtualPath": "System.Runtime.Intrinsics.wasm",
        "name": "System.Runtime.Intrinsics.wasm",
        "hash": "sha256-1IzF0Vlmxk5wwK9F4iPItBGp458rYFRIRoL+P+nE31E="
      },
      {
        "virtualPath": "System.Runtime.Loader.wasm",
        "name": "System.Runtime.Loader.wasm",
        "hash": "sha256-5OHbxN2SFrbLS8ZVpNjGoOGIdu0a1l3yztqToJDQ/J8="
      },
      {
        "virtualPath": "System.Runtime.Numerics.wasm",
        "name": "System.Runtime.Numerics.wasm",
        "hash": "sha256-+W9AHHSWBBvIKcIcOK8+PahW7nlvJ1vusnpKfWBrBQ4="
      },
      {
        "virtualPath": "System.Runtime.Serialization.Formatters.wasm",
        "name": "System.Runtime.Serialization.Formatters.wasm",
        "hash": "sha256-RyvqU2OZI6AnF8t82V06TxqHAHHn8NaljT8Ncldcxao="
      },
      {
        "virtualPath": "System.Runtime.Serialization.Json.wasm",
        "name": "System.Runtime.Serialization.Json.wasm",
        "hash": "sha256-NARCroHZ2O1mQFia4MyiU1G/VW9eCo3IjOFBuiVyRCs="
      },
      {
        "virtualPath": "System.Runtime.Serialization.Xml.wasm",
        "name": "System.Runtime.Serialization.Xml.wasm",
        "hash": "sha256-/Eah06dEuxfoxFcZm9TTuSaBe7n3xDeQy1gptXcSKQY="
      },
      {
        "virtualPath": "System.Security.Claims.wasm",
        "name": "System.Security.Claims.wasm",
        "hash": "sha256-QIJRpCRbl4dxWQvB+y175KdVoKsa3SKhvDU63p1NjSk="
      },
      {
        "virtualPath": "System.Security.Cryptography.wasm",
        "name": "System.Security.Cryptography.wasm",
        "hash": "sha256-EtCAv8n8nbXWUJNH16d5QxTfbrvBzSNzfiMZBRA5N64="
      },
      {
        "virtualPath": "System.Text.Encoding.Extensions.wasm",
        "name": "System.Text.Encoding.Extensions.wasm",
        "hash": "sha256-+2IaqmBVxgOQTPdIXxgN3E1rFrKF2FbrJjMQXk/hTYI="
      },
      {
        "virtualPath": "System.Text.Encodings.Web.wasm",
        "name": "System.Text.Encodings.Web.wasm",
        "hash": "sha256-KE1IZnK+6FnUr7trI5TkgzHoQM+V5jv0eNCeRBsJLe4="
      },
      {
        "virtualPath": "System.Text.Json.wasm",
        "name": "System.Text.Json.wasm",
        "hash": "sha256-l+6ENG8C+N4wjbD5AvxZ88m8DNtKEXU/Sr1U+Eg3r3c="
      },
      {
        "virtualPath": "System.Text.RegularExpressions.wasm",
        "name": "System.Text.RegularExpressions.wasm",
        "hash": "sha256-yYngzwHHVKQmctmqWBLXjZAP9IDaBmufKptZ3ZG0igw="
      },
      {
        "virtualPath": "System.Threading.wasm",
        "name": "System.Threading.wasm",
        "hash": "sha256-9X+1K6mS7kkzS1WmqZb2t2PboRnCs7BDKrl2VKY82kY="
      },
      {
        "virtualPath": "System.Threading.Overlapped.wasm",
        "name": "System.Threading.Overlapped.wasm",
        "hash": "sha256-po8mijnvDrjmX2ZPiEB7JjP4fkhVpdFSH0saq/3GL1s="
      },
      {
        "virtualPath": "System.Threading.Thread.wasm",
        "name": "System.Threading.Thread.wasm",
        "hash": "sha256-DCBIuZi/+cFHbIbyYcvSEIjixZql4WX8y6SDqdchzIM="
      },
      {
        "virtualPath": "System.Threading.ThreadPool.wasm",
        "name": "System.Threading.ThreadPool.wasm",
        "hash": "sha256-AoW+Z5I4YsPg0DfO1jp/3+S3Adv6yNd180cjcnhTFfk="
      },
      {
        "virtualPath": "System.Xml.ReaderWriter.wasm",
        "name": "System.Xml.ReaderWriter.wasm",
        "hash": "sha256-+2pF+t60QflY9rozY1zH4sfjQ0kanCkw/eB0bIsB8N8="
      },
      {
        "virtualPath": "System.Xml.XDocument.wasm",
        "name": "System.Xml.XDocument.wasm",
        "hash": "sha256-gNZzloqK+wF9bMvLliH2i+tW1LdpnyHr9KljWHGaNVw="
      },
      {
        "virtualPath": "System.Xml.XmlSerializer.wasm",
        "name": "System.Xml.XmlSerializer.wasm",
        "hash": "sha256-oFw15W9dbw0vrITcCiuRjUHcEERj3OS1rkezQVC5EhQ="
      },
      {
        "virtualPath": "System.Xml.XPath.wasm",
        "name": "System.Xml.XPath.wasm",
        "hash": "sha256-md37JQTccqACaY1N/UmoKZM2G1MAPh+vn+u1I6mmEsU="
      },
      {
        "virtualPath": "System.Xml.XPath.XDocument.wasm",
        "name": "System.Xml.XPath.XDocument.wasm",
        "hash": "sha256-xjjR+stJ8ENwr4JOA4C3yEIWg8bZbVwVajMBQ/SM56I="
      },
      {
        "virtualPath": "TraceCode.CSharpJudgeRunner.wasm",
        "name": "TraceCode.CSharpJudgeRunner.wasm",
        "hash": "sha256-cHmX3dHJAS9cchy+9Dj8HyO9dN9zIF6+aGu/BlkiSoI="
      },
      {
        "virtualPath": "TraceCode.CSharpJudgeRuntime.wasm",
        "name": "TraceCode.CSharpJudgeRuntime.wasm",
        "hash": "sha256-7reunYxCJNonpVssojwhzMJHFoPDCYJLvJTAEkiWG2I="
      }
    ],
    "extensions": {
      "tracecodeAssemblyPacks": {
        "schema": "tracecode.csharp-assembly-packs.v1",
        "assemblyCount": 61,
        "packs": [
          {
            "name": "assemblies-01.pack",
            "hash": "sha256-nVRQo2okpMBgigwx8PBc6oboCsuGtUTyxDYV/XEWzAA=",
            "bytes": 4543507,
            "assemblyCount": 1,
            "assemblies": [
              "System.Private.CoreLib.wasm"
            ]
          },
          {
            "name": "assemblies-02.pack",
            "hash": "sha256-hJ3SUiMXKe8uwdBawHwBUsnud2Lrnx087SZ3fSKYCMY=",
            "bytes": 1607383,
            "assemblyCount": 30,
            "assemblies": [
              "System.Runtime.InteropServices.JavaScript.wasm",
              "Microsoft.CSharp.wasm",
              "mscorlib.wasm",
              "System.Collections.Concurrent.wasm",
              "System.Collections.Specialized.wasm",
              "System.ComponentModel.wasm",
              "System.ComponentModel.Primitives.wasm",
              "System.ComponentModel.TypeConverter.wasm",
              "System.Core.wasm",
              "System.Diagnostics.Contracts.wasm",
              "System.IO.MemoryMappedFiles.wasm",
              "System.Numerics.Vectors.wasm",
              "System.Reflection.Emit.wasm",
              "System.Reflection.Emit.Lightweight.wasm",
              "System.Reflection.Metadata.wasm",
              "System.Resources.Writer.wasm",
              "System.Runtime.wasm",
              "System.Runtime.Extensions.wasm",
              "System.Runtime.InteropServices.wasm",
              "System.Runtime.Loader.wasm",
              "System.Runtime.Numerics.wasm",
              "System.Runtime.Serialization.Xml.wasm",
              "System.Text.Encoding.Extensions.wasm",
              "System.Text.Json.wasm",
              "System.Threading.ThreadPool.wasm",
              "System.Xml.XDocument.wasm",
              "System.Xml.XmlSerializer.wasm",
              "System.Xml.XPath.XDocument.wasm",
              "TraceCode.CSharpJudgeRunner.wasm",
              "TraceCode.CSharpJudgeRuntime.wasm"
            ]
          },
          {
            "name": "assemblies-03.pack",
            "hash": "sha256-UON1SRYguiKFTgl+/qnOgJfAXo9m+SBS6703GzONjZ4=",
            "bytes": 1606767,
            "assemblyCount": 30,
            "assemblies": [
              "Microsoft.Win32.Primitives.wasm",
              "netstandard.wasm",
              "System.Collections.wasm",
              "System.Collections.Immutable.wasm",
              "System.Collections.NonGeneric.wasm",
              "System.Console.wasm",
              "System.Diagnostics.DiagnosticSource.wasm",
              "System.Diagnostics.StackTrace.wasm",
              "System.Diagnostics.Tracing.wasm",
              "System.wasm",
              "System.IO.Pipelines.wasm",
              "System.Linq.wasm",
              "System.Linq.Expressions.wasm",
              "System.Memory.wasm",
              "System.ObjectModel.wasm",
              "System.Private.Uri.wasm",
              "System.Reflection.Emit.ILGeneration.wasm",
              "System.Reflection.Primitives.wasm",
              "System.Runtime.Intrinsics.wasm",
              "System.Runtime.Serialization.Formatters.wasm",
              "System.Runtime.Serialization.Json.wasm",
              "System.Security.Claims.wasm",
              "System.Security.Cryptography.wasm",
              "System.Text.Encodings.Web.wasm",
              "System.Text.RegularExpressions.wasm",
              "System.Threading.wasm",
              "System.Threading.Overlapped.wasm",
              "System.Threading.Thread.wasm",
              "System.Xml.ReaderWriter.wasm",
              "System.Xml.XPath.wasm"
            ]
          }
        ]
      }
    }
  },
  "debugLevel": 0,
  "globalizationMode": "invariant",
  "runtimeConfig": {
    "runtimeOptions": {
      "configProperties": {
        "Microsoft.Extensions.DependencyInjection.VerifyOpenGenericServiceTrimmability": true,
        "System.ComponentModel.DefaultValueAttribute.IsSupported": false,
        "System.ComponentModel.Design.IDesignerHost.IsSupported": false,
        "System.ComponentModel.TypeConverter.EnableUnsafeBinaryFormatterInDesigntimeLicenseContextSerialization": false,
        "System.ComponentModel.TypeDescriptor.IsComObjectDescriptorSupported": false,
        "System.Data.DataSet.XmlSerializationIsSupported": false,
        "System.Diagnostics.Debugger.IsSupported": false,
        "System.Diagnostics.Metrics.Meter.IsSupported": false,
        "System.Diagnostics.Tracing.EventSource.IsSupported": false,
        "System.Globalization.Invariant": true,
        "System.TimeZoneInfo.Invariant": false,
        "System.Globalization.PredefinedCulturesOnly": true,
        "System.Linq.Enumerable.IsSizeOptimized": true,
        "System.Net.Http.EnableActivityPropagation": false,
        "System.Net.Http.WasmEnableStreamingResponse": true,
        "System.Net.SocketsHttpHandler.Http3Support": false,
        "System.Reflection.Metadata.MetadataUpdater.IsSupported": false,
        "System.Resources.ResourceManager.AllowCustomResourceTypes": false,
        "System.Resources.UseSystemResourceKeys": true,
        "System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported": true,
        "System.Runtime.InteropServices.BuiltInComInterop.IsSupported": false,
        "System.Runtime.InteropServices.EnableConsumingManagedCodeFromNativeHosting": false,
        "System.Runtime.InteropServices.EnableCppCLIHostActivation": false,
        "System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop": false,
        "System.Runtime.Serialization.EnableUnsafeBinaryFormatterSerialization": false,
        "System.StartupHookProvider.IsSupported": false,
        "System.Text.Encoding.EnableUnsafeUTF7Encoding": false,
        "System.Text.Json.JsonSerializer.IsReflectionEnabledByDefault": true,
        "System.Threading.Thread.EnableAutoreleasePool": false
      }
    }
  }
}/*json-end*/;